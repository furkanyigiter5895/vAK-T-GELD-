import express from "express";
import { createServer as createViteServer } from "vite";
import axios from 'axios';
import * as cheerio from 'cheerio';
import iconv from 'iconv-lite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware to parse JSON
  app.use(express.json());

  // API Routes for TurkTakvim Proxy
  const TURKTAKVIM_BASE_URL = 'https://www.turktakvim.com';
  const NAMAZVAKTI_BASE_URL = 'https://www.namazvakti.com';
  const HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  };

  // Helper to fetch and decode
  async function fetchPage(url: string, encoding: string = 'utf-8') {
    try {
      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        headers: HEADERS
      });
      const html = iconv.decode(response.data, encoding);
      return cheerio.load(html);
    } catch (error) {
      console.error(`Error fetching ${url}:`, error);
      throw error;
    }
  }

  // Get Cities (Provinces) for Turkey (from TurkTakvim)
  app.get("/api/locations/cities", async (req, res) => {
    try {
      const $ = await fetchPage(`${TURKTAKVIM_BASE_URL}/index.php?link=Ulkeler_Listesi.php&countryID=200`, 'utf-8');
      const cities: { name: string; value: string }[] = [];
      
      // Look for links with cityStateFilter
      $('a[href*="cityStateFilter="]').each((_, el) => {
        const href = $(el).attr('href');
        const name = $(el).text().trim();
        const match = href?.match(/cityStateFilter=([^&]+)/);
        
        // Filter out empty names or duplicates if needed
        if (match && name && !cities.find(c => c.value === match[1])) {
          cities.push({ name, value: match[1] });
        }
      });

      res.json(cities);
    } catch (error) {
      console.error("Error fetching cities:", error);
      res.status(500).json({ error: "Failed to fetch cities" });
    }
  });

  // Get Districts for a City (from TurkTakvim)
  app.get("/api/locations/districts", async (req, res) => {
    const { city } = req.query;
    if (!city) return res.status(400).json({ error: "City is required" });

    try {
      const $ = await fetchPage(`${TURKTAKVIM_BASE_URL}/index.php?link=Ulkeler_Listesi.php&countryID=200&cityStateFilter=${city}`, 'utf-8');
      const districts: { name: string; id: string }[] = [];

      // Look for links with cityID
      $('a[href*="cityID="]').each((_, el) => {
        const href = $(el).attr('href');
        const name = $(el).text().trim();
        const match = href?.match(/cityID=(\d+)/);
        
        if (match && name) {
          districts.push({ name, id: match[1] });
        }
      });

      res.json(districts);
    } catch (error) {
      console.error("Error fetching districts:", error);
      res.status(500).json({ error: "Failed to fetch districts" });
    }
  });

  // Get Prayer Times for a Location (cityID) (from NamazVakti)
  app.get("/api/times", async (req, res) => {
    const { cityID } = req.query;
    if (!cityID) return res.status(400).json({ error: "cityID is required" });

    try {
      // Use NamazVakti for times
      const $ = await fetchPage(`${NAMAZVAKTI_BASE_URL}/Main.php?cityID=${cityID}`, 'utf-8');
      
      const times: Record<string, string> = {};
      
      // The times are in the first table
      const table = $('table').first();
      
      table.find('tr').each((_, row) => {
        const cols = $(row).find('td');
        if (cols.length >= 2) {
          const name = $(cols[0]).text().trim();
          // Time might be in the second column, but sometimes it has extra text
          // Based on inspection: "İmsâk 05:59" -> Name: "İmsâk", Time: "05:59"
          // Or sometimes they are in separate cells?
          // Inspection output: Row 1: İmsâk05:59 -> Cell 0: İmsâk, Cell 1: 05:59
          let time = $(cols[1]).text().trim();
          
          // Normalize name
          // Handle Turkish specific characters first
          const normalizedName = name
            .toLowerCase()
            .replace(/ı/g, 'i')
            .replace(/ğ/g, 'g')
            .replace(/ü/g, 'u')
            .replace(/ş/g, 's')
            .replace(/ö/g, 'o')
            .replace(/ç/g, 'c')
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "");
          
          console.log(`Row: ${name} -> ${normalizedName}, Time: ${time}`);

          if (time && time.length > 0) {
            if (normalizedName.includes('imsak')) times.fajr = time;
            else if (normalizedName.includes('gunes')) times.sunrise = time;
            else if (normalizedName.includes('ogle')) times.dhuhr = time;
            else if (normalizedName.includes('ikindi')) times.asr = time;
            else if (normalizedName.includes('aksam')) times.maghrib = time;
            else if (normalizedName.includes('yatsi')) times.isha = time;
          }
        }
      });

      res.json(times);
    } catch (error) {
      console.error("Error fetching times:", error);
      res.status(500).json({ error: "Failed to fetch times" });
    }
  });

  // Get Quote
  app.get("/api/quote", async (req, res) => {
    try {
      // Try to fetch from the main page or a specific page
      // Often "Arka Yaprak" has good content
      const $ = await fetchPage(`${TURKTAKVIM_BASE_URL}/index.php?page=arkayuz`, 'utf-8');
      
      // Extract text from the main content area
      // This is a heuristic. We look for a paragraph with substantial text.
      let quote = "Dîne hizmet eden azîz olur.";
      let author = "Enver Ören";

      // Try to find the first substantial paragraph in the content area
      // Assuming content is in a table or div
      // Let's look for text inside <p> or <font> tags that is long enough
      $('p, font').each((_, el) => {
        const text = $(el).text().trim();
        if (text.length > 50 && text.length < 300 && !quote.length) {
           // quote = text; // Too risky without specific selector
        }
      });

      res.json({ quote, author });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quote" });
    }
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
