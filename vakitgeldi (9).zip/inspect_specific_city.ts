import axios from 'axios';
import * as cheerio from 'cheerio';
import iconv from 'iconv-lite';

async function inspect() {
  try {
    const url = 'https://www.turktakvim.com/index.php?cityID=17639';
    console.log(`Fetching ${url}...`);
    const response = await axios.get(url, {
      responseType: 'arraybuffer',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    // Try decoding with utf-8
    const html = iconv.decode(response.data, 'utf-8');
    const $ = cheerio.load(html);

    console.log("Title:", $('title').text());
    
    // Check for table data
    const tables = $('table');
    console.log(`Found ${tables.length} tables.`);
    
    tables.each((i, table) => {
      console.log(`Table ${i} content sample:`, $(table).text().substring(0, 100).replace(/\s+/g, ' '));
      // Check rows
      const rows = $(table).find('tr');
      console.log(`Table ${i} has ${rows.length} rows.`);
      rows.each((j, row) => {
        if (j < 5) {
            console.log(`  Row ${j}:`, $(row).text().replace(/\s+/g, ' '));
        }
      });
    });

    // Check for city name to verify encoding
    // Usually the city name is in a header tag
    console.log("H1 tags:", $('h1').text());
    console.log("H2 tags:", $('h2').text());
    console.log("H3 tags:", $('h3').text());

  } catch (error) {
    console.error(error);
  }
}

inspect();
