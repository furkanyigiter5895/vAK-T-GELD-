import axios from 'axios';

async function checkCities() {
  try {
    const response = await axios.get('http://localhost:3000/api/locations/cities');
    console.log("Cities count:", response.data.length);
    if (response.data.length > 0) {
        console.log("First city:", response.data[0]);
    }
  } catch (error) {
    console.error(error);
  }
}

checkCities();
