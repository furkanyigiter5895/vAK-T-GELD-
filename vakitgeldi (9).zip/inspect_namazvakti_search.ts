import axios from 'axios';
import * as cheerio from 'cheerio';

async function inspectSearch() {
  try {
    const searchUrl = 'https://www.namazvakti.com/CitySearch.php?';
    console.log(`Fetching ${searchUrl}...`);
    const searchResponse = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    const $ = cheerio.load(searchResponse.data);
    
    console.log("Search Page Title:", $('title').text());
    
    // Inspect Main.php for prayer times
    const cityUrl = 'https://www.namazvakti.com/Main.php?cityID=16741';
    console.log(`Fetching ${cityUrl}...`);
    const cityResponse = await axios.get(cityUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    const $city = cheerio.load(cityResponse.data);
    
    console.log("City Page Title:", $city('title').text());
    
    // Check if ID 17639 corresponds to Yahyali in namazvakti
    const yahyaliUrl = 'https://www.namazvakti.com/Main.php?cityID=17639';
    console.log(`Fetching ${yahyaliUrl}...`);
    const yahyaliResponse = await axios.get(yahyaliUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    const $yahyali = cheerio.load(yahyaliResponse.data);
    console.log("Yahyali Page Title:", $yahyali('title').text());

  } catch (error) {
    console.error(error);
  }
}

inspectSearch();
