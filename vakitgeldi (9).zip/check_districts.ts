import axios from 'axios';

async function checkDistricts() {
  const cities = ['ANDALYA'];
  
  for (const city of cities) {
    try {
      console.log(`Fetching districts for ${city}...`);
      const response = await axios.get(`http://localhost:3000/api/locations/districts?city=${city}`);
      console.log(`  ${city}: ${response.data.length} districts found.`);
      if (response.data.length > 0) {
          console.log(`  First: ${response.data[0].name} (${response.data[0].id})`);
      }
    } catch (error) {
      console.error(`  Error fetching districts for ${city}:`, error.message);
    }
  }
}

checkDistricts();
