import axios from 'axios';
import * as cheerio from 'cheerio';

async function inspectYatsi() {
  try {
    const url = 'https://www.namazvakti.com/Main.php?cityID=16741';
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    const table = $('table').first();
    
    table.find('tr').each((i, row) => {
      const cols = $(row).find('td');
      if (cols.length >= 2) {
        const name = $(cols[0]).text().trim();
        const time = $(cols[1]).text().trim();
        const normalizedName = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
        
        console.log(`Row ${i}: Name="${name}" Normalized="${normalizedName}" Time="${time}"`);
        
        if (normalizedName.includes('yatsi')) {
            console.log("  MATCHES YATSI");
        } else {
            console.log("  NO MATCH");
        }
      }
    });

  } catch (error) {
    console.error(error);
  }
}

inspectYatsi();
