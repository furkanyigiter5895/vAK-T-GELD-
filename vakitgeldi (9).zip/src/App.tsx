import React, { useState, useEffect } from 'react';
import Dashboard from './components/Dashboard';
import LocationSelector from './components/LocationSelector';
import Settings from './components/Settings';

interface Location {
  name: string;
  cityID: string;
}

export default function App() {
  const [location, setLocation] = useState<Location | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'dashboard' | 'settings'>('dashboard');

  useEffect(() => {
    // Check local storage for saved location
    const savedLocation = localStorage.getItem('vakitgeldi_location_v2');
    if (savedLocation) {
      try {
        setLocation(JSON.parse(savedLocation));
      } catch (e) {
        console.error("Failed to parse saved location", e);
      }
    }
    setLoading(false);
  }, []);

  const handleLocationSelect = (loc: Location) => {
    setLocation(loc);
    localStorage.setItem('vakitgeldi_location_v2', JSON.stringify(loc));
  };

  const handleResetLocation = () => {
    setLocation(null);
    localStorage.removeItem('vakitgeldi_location_v2');
  };

  const handleOpenSettings = () => {
    setView('settings');
  };

  const handleCloseSettings = () => {
    setView('dashboard');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (view === 'settings') {
    return <Settings onBack={handleCloseSettings} />;
  }

  return (
    <>
      {location ? (
        <Dashboard 
          location={location} 
          onResetLocation={handleResetLocation} 
          onOpenSettings={handleOpenSettings}
        />
      ) : (
        <LocationSelector onLocationSelect={handleLocationSelect} />
      )}
    </>
  );
}
