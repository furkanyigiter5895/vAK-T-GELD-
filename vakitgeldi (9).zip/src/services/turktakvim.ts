export interface City {
  name: string;
  value: string; // Used for cityStateFilter
}

export interface District {
  name: string;
  id: string; // cityID
}

export interface PrayerTimes {
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
}

export interface Quote {
  quote: string;
  author: string;
}

export async function getCities(): Promise<City[]> {
  const response = await fetch('/api/locations/cities');
  if (!response.ok) throw new Error('Failed to fetch cities');
  return response.json();
}

export async function getDistricts(city: string): Promise<District[]> {
  const response = await fetch(`/api/locations/districts?city=${encodeURIComponent(city)}`);
  if (!response.ok) throw new Error('Failed to fetch districts');
  return response.json();
}

export async function getPrayerTimes(cityID: string): Promise<PrayerTimes> {
  const response = await fetch(`/api/times?cityID=${cityID}`);
  if (!response.ok) throw new Error('Failed to fetch prayer times');
  return response.json();
}

export async function getQuote(): Promise<Quote> {
  const response = await fetch('/api/quote');
  if (!response.ok) throw new Error('Failed to fetch quote');
  return response.json();
}
