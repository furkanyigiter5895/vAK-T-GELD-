import React, { useState, useEffect } from 'react';
import { ArrowLeft, Save, Bell, Clock, VolumeX, Watch, Navigation, Home, Compass, BookOpen, Settings as SettingsIcon, Plus, Minus } from 'lucide-react';
import { motion } from 'motion/react';

interface SettingsProps {
  onBack: () => void;
}

export default function Settings({ onBack }: SettingsProps) {
  const [settings, setSettings] = useState({
    ezanNotification: false,
    preWarning: true,
    preWarningTime: 15,
    autoSilent: false,
    silentDuration: 30,
    gpsLocation: true,
  });

  useEffect(() => {
    const saved = localStorage.getItem('vakitgeldi_settings');
    if (saved) {
      setSettings(JSON.parse(saved));
    }
  }, []);

  const saveSettings = () => {
    localStorage.setItem('vakitgeldi_settings', JSON.stringify(settings));
    onBack();
  };

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key as keyof typeof settings] }));
  };

  const updateSetting = (key: keyof typeof settings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-100 font-sans antialiased transition-colors duration-200 pb-24">
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            <ArrowLeft className="w-6 h-6 text-gray-800 dark:text-gray-100" />
          </button>
          <h1 className="text-lg font-semibold tracking-wide">Bildirim ve Saat</h1>
          <button onClick={saveSettings} className="p-2 -mr-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            <Save className="w-6 h-6 text-emerald-500" />
          </button>
        </div>
      </header>

      <main className="max-w-md mx-auto px-4 pt-6 space-y-6">
        {/* Notification Settings */}
        <section className="space-y-4">
          <h2 className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider ml-1">BİLDİRİM AYARLARI</h2>
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
            <div className="p-4 flex items-center justify-between border-b border-gray-100 dark:border-gray-700">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400">
                  <Bell className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-medium">Ezan Vakti Bildirimi</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Vakit girdiğinde anında bildirim</p>
                </div>
              </div>
              <div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
                <input 
                  checked={settings.ezanNotification}
                  onChange={() => toggleSetting('ezanNotification')}
                  type="checkbox" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 border-gray-300 dark:border-gray-600 appearance-none cursor-pointer checked:border-emerald-500 transition-all duration-200 right-6 checked:right-0"
                />
                <label 
                  onClick={() => toggleSetting('ezanNotification')}
                  className={`toggle-label block overflow-hidden h-6 rounded-full cursor-pointer transition-colors duration-200 ${settings.ezanNotification ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                ></label>
              </div>
            </div>
            
            <div className="p-4 flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center text-orange-600 dark:text-orange-400">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-medium">Vakit Öncesi Uyarı</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Hazırlık için hatırlatma</p>
                  </div>
                </div>
                <div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
                  <input 
                    checked={settings.preWarning}
                    onChange={() => toggleSetting('preWarning')}
                    type="checkbox" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 border-gray-300 dark:border-gray-600 appearance-none cursor-pointer checked:border-emerald-500 transition-all duration-200 right-6 checked:right-0"
                  />
                  <label 
                    onClick={() => toggleSetting('preWarning')}
                    className={`toggle-label block overflow-hidden h-6 rounded-full cursor-pointer transition-colors duration-200 ${settings.preWarning ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                  ></label>
                </div>
              </div>
              
              {settings.preWarning && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  className="bg-gray-50 dark:bg-gray-900 rounded-lg p-3 flex items-center justify-between"
                >
                  <span className="text-sm font-medium">Süre Seçimi</span>
                  <div className="flex items-center space-x-2">
                    <button 
                      onClick={() => updateSetting('preWarningTime', Math.max(5, settings.preWarningTime - 5))}
                      className="w-8 h-8 rounded-full bg-white dark:bg-gray-800 shadow text-emerald-500 flex items-center justify-center hover:bg-gray-50 dark:hover:bg-gray-700"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="font-bold w-12 text-center">{settings.preWarningTime} dk</span>
                    <button 
                      onClick={() => updateSetting('preWarningTime', Math.min(60, settings.preWarningTime + 5))}
                      className="w-8 h-8 rounded-full bg-white dark:bg-gray-800 shadow text-emerald-500 flex items-center justify-center hover:bg-gray-50 dark:hover:bg-gray-700"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </section>

        {/* Worship Mode */}
        <section className="space-y-4">
          <h2 className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider ml-1">İBADET MODU</h2>
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-purple-600 dark:text-purple-400">
                  <VolumeX className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-medium">Otomatik Sessiz Mod</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Ezandan sonra telefonu sessize al</p>
                </div>
              </div>
              <div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
                <input 
                  checked={settings.autoSilent}
                  onChange={() => toggleSetting('autoSilent')}
                  type="checkbox" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 border-gray-300 dark:border-gray-600 appearance-none cursor-pointer checked:border-emerald-500 transition-all duration-200 right-6 checked:right-0"
                />
                <label 
                  onClick={() => toggleSetting('autoSilent')}
                  className={`toggle-label block overflow-hidden h-6 rounded-full cursor-pointer transition-colors duration-200 ${settings.autoSilent ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                ></label>
              </div>
            </div>
            
            {settings.autoSilent && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                className="pl-[3.25rem]"
              >
                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                  <span>Sessiz Kalma Süresi</span>
                  <select 
                    value={settings.silentDuration}
                    onChange={(e) => updateSetting('silentDuration', parseInt(e.target.value))}
                    className="bg-gray-50 dark:bg-gray-900 border-none rounded-lg text-sm font-medium py-1 px-3 focus:ring-1 focus:ring-emerald-500 outline-none"
                  >
                    <option value={20}>20 Dakika</option>
                    <option value={30}>30 Dakika</option>
                    <option value={45}>45 Dakika</option>
                    <option value={60}>1 Saat</option>
                  </select>
                </div>
              </motion.div>
            )}
          </div>
        </section>

        {/* Smart Watch */}
        <section className="space-y-4">
          <h2 className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider ml-1">AKILLI SAAT</h2>
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-4 relative overflow-hidden group cursor-pointer hover:border-emerald-500 transition-colors">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full -mr-10 -mt-10 blur-xl"></div>
            <div className="flex items-start justify-between">
              <div className="flex-1 pr-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Watch className="text-emerald-500 w-5 h-5" />
                  <h3 className="font-medium text-lg">Apple Watch Senkronizasyonu</h3>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  Saat yüzünde geri sayım ve vakit bilgilerini görüntüleyin.
                </p>
                <button className="text-sm font-medium text-emerald-500 hover:text-emerald-400 transition-colors flex items-center space-x-1">
                  <span>Ayarları Yapılandır</span>
                  <ArrowLeft className="w-4 h-4 rotate-180" />
                </button>
              </div>
              <div className="relative flex-shrink-0">
                <div className="w-20 h-24 bg-gray-900 rounded-[1.2rem] border-2 border-gray-700 shadow-xl flex items-center justify-center relative overflow-hidden">
                  <div className="w-full h-full bg-black flex flex-col items-center justify-center p-1">
                    <span className="text-[8px] text-gray-400 font-medium">İKİNDİ</span>
                    <span className="text-white font-bold text-lg leading-none mt-1">16:30</span>
                    <span className="text-[8px] text-emerald-500 mt-1 font-medium">-01:14</span>
                    <svg className="absolute inset-0 w-full h-full rotate-[-90deg] p-1 pointer-events-none">
                      <circle cx="50%" cy="50%" fill="none" r="32%" stroke="#333" strokeWidth="2"></circle>
                      <circle cx="50%" cy="50%" fill="none" r="32%" stroke="#14b8a6" strokeDasharray="100" strokeDashoffset="30" strokeLinecap="round" strokeWidth="2"></circle>
                    </svg>
                  </div>
                  <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-white/10 to-transparent pointer-events-none rounded-t-[1rem]"></div>
                </div>
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white dark:border-gray-800"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Location */}
        <section className="space-y-4">
          <h2 className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider ml-1">KONUM</h2>
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                <Navigation className="w-6 h-6" />
              </div>
              <div>
                <p className="font-medium">GPS Konumu Kullan</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">İstanbul, TR (Otomatik)</p>
              </div>
            </div>
            <div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
              <input 
                checked={settings.gpsLocation}
                onChange={() => toggleSetting('gpsLocation')}
                type="checkbox" 
                className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 border-gray-300 dark:border-gray-600 appearance-none cursor-pointer checked:border-emerald-500 transition-all duration-200 right-6 checked:right-0"
              />
              <label 
                onClick={() => toggleSetting('gpsLocation')}
                className={`toggle-label block overflow-hidden h-6 rounded-full cursor-pointer transition-colors duration-200 ${settings.gpsLocation ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-600'}`}
              ></label>
            </div>
          </div>
        </section>
      </main>

      <nav className="fixed bottom-0 w-full bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 pb-6 pt-3 px-6 shadow-lg z-50">
        <div className="flex justify-between items-center max-w-md mx-auto">
          <button onClick={onBack} className="flex flex-col items-center space-y-1 text-gray-500 dark:text-gray-400 hover:text-emerald-500 dark:hover:text-emerald-500">
            <Home className="w-6 h-6" />
            <span className="text-[10px] font-medium">Ana Sayfa</span>
          </button>
          <button className="flex flex-col items-center space-y-1 text-gray-500 dark:text-gray-400 hover:text-emerald-500 dark:hover:text-emerald-500">
            <Compass className="w-6 h-6" />
            <span className="text-[10px] font-medium">Kıble</span>
          </button>
          <button className="flex flex-col items-center space-y-1 text-emerald-500">
            <SettingsIcon className="w-6 h-6" />
            <span className="text-[10px] font-medium">Ayarlar</span>
          </button>
          <button className="flex flex-col items-center space-y-1 text-gray-500 dark:text-gray-400 hover:text-emerald-500 dark:hover:text-emerald-500">
            <BookOpen className="w-6 h-6" />
            <span className="text-[10px] font-medium">Kuran</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
