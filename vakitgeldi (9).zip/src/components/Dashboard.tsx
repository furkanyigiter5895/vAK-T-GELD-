import React, { useEffect, useState, useRef } from 'react';
import { motion } from 'motion/react';
import { 
  Bell, Settings, MapPin, Watch, 
  Sunrise, Sun, SunDim, Sunset, Moon, 
  Quote, Compass, Calendar, Home, Library, User,
  Navigation, BookOpen
} from 'lucide-react';
import { getPrayerTimes, getQuote, PrayerTimes, Quote as QuoteType } from '../services/turktakvim';
import { getHijriDate, getGregorianDate } from '../lib/prayer-times';

interface DashboardProps {
  location: { name: string; cityID: string };
  onResetLocation: () => void;
  onOpenSettings: () => void;
}

export default function Dashboard({ location, onResetLocation, onOpenSettings }: DashboardProps) {
  const [times, setTimes] = useState<PrayerTimes | null>(null);
  const [quote, setQuote] = useState<QuoteType | null>(null);
  const [timeLeft, setTimeLeft] = useState<string>("");
  const [nextPrayerName, setNextPrayerName] = useState<string>("");
  const [activePrayerKey, setActivePrayerKey] = useState<string>("");
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(true);

  // Audio for notifications
  const hasNotifiedRef = useRef<Record<string, boolean>>({});

  useEffect(() => {
    async function fetchData() {
      try {
        const [timesData, quoteData] = await Promise.all([
          getPrayerTimes(location.cityID),
          getQuote()
        ]);
        setTimes(timesData);
        setQuote(quoteData);
      } catch (error) {
        console.error("Failed to fetch data", error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [location.cityID]);

  useEffect(() => {
    if (!times) return;

    const calculateTimeLeft = () => {
      const now = new Date();
      const currentHours = now.getHours();
      const currentMinutes = now.getMinutes();
      const currentSeconds = now.getSeconds();
      const currentTimeInMinutes = currentHours * 60 + currentMinutes;

      // Parse times
      const parseTime = (timeStr: string) => {
        if (!timeStr) return 0;
        const [h, m] = timeStr.split(':').map(Number);
        return h * 60 + m;
      };

      const prayerMinutes = {
        fajr: parseTime(times.fajr),
        sunrise: parseTime(times.sunrise),
        dhuhr: parseTime(times.dhuhr),
        asr: parseTime(times.asr),
        maghrib: parseTime(times.maghrib),
        isha: parseTime(times.isha),
      };

      // Determine next prayer
      let nextKey = 'fajr';
      let nextTime = prayerMinutes.fajr;
      let activeKey = 'isha';

      if (currentTimeInMinutes < prayerMinutes.fajr) {
        nextKey = 'fajr';
        nextTime = prayerMinutes.fajr;
        activeKey = 'isha';
      } else if (currentTimeInMinutes < prayerMinutes.sunrise) {
        nextKey = 'sunrise';
        nextTime = prayerMinutes.sunrise;
        activeKey = 'fajr';
      } else if (currentTimeInMinutes < prayerMinutes.dhuhr) {
        nextKey = 'dhuhr';
        nextTime = prayerMinutes.dhuhr;
        activeKey = 'sunrise';
      } else if (currentTimeInMinutes < prayerMinutes.asr) {
        nextKey = 'asr';
        nextTime = prayerMinutes.asr;
        activeKey = 'dhuhr';
      } else if (currentTimeInMinutes < prayerMinutes.maghrib) {
        nextKey = 'maghrib';
        nextTime = prayerMinutes.maghrib;
        activeKey = 'asr';
      } else if (currentTimeInMinutes < prayerMinutes.isha) {
        nextKey = 'isha';
        nextTime = prayerMinutes.isha;
        activeKey = 'maghrib';
      } else {
        nextKey = 'fajr';
        nextTime = prayerMinutes.fajr + 24 * 60;
        activeKey = 'isha';
      }

      setNextPrayerName(nextKey);
      setActivePrayerKey(activeKey);

      // Calculate time left
      let diffMinutes = nextTime - currentTimeInMinutes;
      if (diffMinutes < 0) diffMinutes += 24 * 60;

      const hoursLeft = Math.floor(diffMinutes / 60);
      const minutesLeft = Math.floor(diffMinutes % 60);
      const secondsLeft = 59 - currentSeconds;

      setTimeLeft(`${hoursLeft.toString().padStart(2, '0')}:${minutesLeft.toString().padStart(2, '0')}:${secondsLeft.toString().padStart(2, '0')}`);

      // Calculate progress
      let totalDuration = nextTime - prayerMinutes[activeKey];
      if (totalDuration < 0) totalDuration += 24 * 60;
      
      // We want the progress bar to shrink as time passes (like a countdown)
      // Total duration is fixed between two prayers.
      // Remaining time is diffMinutes.
      // Progress = (Remaining / Total) * 100
      // But diffMinutes is in minutes, we should include seconds for smoothness?
      // Let's stick to minutes for simplicity or add seconds fraction.
      const totalMinutes = totalDuration * 60;
      const remainingMinutes = diffMinutes * 60 + secondsLeft;
      
      const percentageRemaining = (remainingMinutes / totalMinutes) * 100;
      setProgress(percentageRemaining);

      // Notifications Logic
      const settings = JSON.parse(localStorage.getItem('vakitgeldi_settings') || '{}');
      const ezanEnabled = settings.ezanNotification === true; 
      const preWarningEnabled = settings.preWarning !== false; 
      const preWarningTime = settings.preWarningTime || 15;

      Object.entries(prayerMinutes).forEach(([key, timeMin]) => {
        // Ezan Notification
        if (ezanEnabled) {
          if (Math.abs(currentTimeInMinutes - timeMin) < 1 && !hasNotifiedRef.current[key]) {
            sendNotification(key, 'ezan');
            hasNotifiedRef.current[key] = true;
            setTimeout(() => { hasNotifiedRef.current[key] = false; }, 60000 * 60);
          }
        }

        // Pre-warning Notification
        if (preWarningEnabled) {
          let diff = timeMin - currentTimeInMinutes;
          if (diff < 0) diff += 24 * 60;
          
          if (Math.abs(diff - preWarningTime) < 1 && !hasNotifiedRef.current[`${key}_pre`]) {
            sendNotification(key, 'pre', preWarningTime);
            hasNotifiedRef.current[`${key}_pre`] = true;
            setTimeout(() => { hasNotifiedRef.current[`${key}_pre`] = false; }, 60000 * 60);
          }
        }
      });
    };

    calculateTimeLeft(); // Run immediately
    const interval = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(interval);
  }, [times]);

  const sendNotification = (prayerKey: string, type: 'ezan' | 'pre' = 'ezan', preTime?: number) => {
    const prayerNames: Record<string, string> = {
      fajr: 'İmsâk',
      sunrise: 'Güneş',
      dhuhr: 'Öğle',
      asr: 'İkindi',
      maghrib: 'Akşam',
      isha: 'Yatsı'
    };
    const name = prayerNames[prayerKey];
    const message = type === 'ezan' 
      ? `${name} vakti geldi.` 
      : `${name} vaktine ${preTime} dakika kaldı.`;

    if (Notification.permission === 'granted') {
      new Notification('VakitGeldi', {
        body: message,
        icon: '/pwa-192x192.png'
      });
    }

    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'tr-TR';
      window.speechSynthesis.speak(utterance);
    }
  };


  const requestNotificationPermission = () => {
    if ('Notification' in window) {
      Notification.requestPermission();
    }
  };

  if (loading || !times) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-slate-900">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  const prayers = [
    { name: 'İmsâk', time: times.fajr, icon: Sunrise, key: 'fajr' },
    { name: 'Güneş', time: times.sunrise, icon: Sun, key: 'sunrise' },
    { name: 'Öğle', time: times.dhuhr, icon: SunDim, key: 'dhuhr' },
    { name: 'İkindi', time: times.asr, icon: Sun, key: 'asr' },
    { name: 'Akşam', time: times.maghrib, icon: Sunset, key: 'maghrib' },
    { name: 'Yatsı', time: times.isha, icon: Moon, key: 'isha' },
  ];

  const prayerNames: Record<string, string> = {
    fajr: 'İmsâk',
    sunrise: 'Güneş',
    dhuhr: 'Öğle',
    asr: 'İkindi',
    maghrib: 'Akşam',
    isha: 'Yatsı'
  };

  // Circular progress calculation
  const radius = 45;
  const circumference = 2 * Math.PI * radius;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 font-sans text-gray-800 dark:text-gray-100 transition-colors duration-300 pb-24">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-gray-50/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="bg-emerald-500 p-1.5 rounded-lg">
               <Home className="text-white w-5 h-5" />
            </div>
            <h1 className="font-display font-bold text-xl tracking-tight text-gray-900 dark:text-white">VakitGeldi</h1>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={requestNotificationPermission}
              className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors relative"
              title="Bildirimleri Aç"
            >
              <Bell className="text-gray-600 dark:text-gray-300 w-6 h-6" />
            </button>
            <button 
              onClick={onResetLocation}
              className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
            >
              <Settings className="text-gray-600 dark:text-gray-300 w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto pt-20 px-4 space-y-6">
        {/* Location & Date */}
        <div className="flex flex-col items-center text-center space-y-1">
          <div className="flex items-center space-x-1 text-sm font-medium text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 px-3 py-1 rounded-full">
            <Navigation className="w-4 h-4" />
            <span>{location.name}</span>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            {getGregorianDate(new Date())} • {getHijriDate(new Date())}
          </p>
        </div>

        {/* Circular Timer */}
        <div className="relative flex flex-col items-center justify-center py-6">
          <div className="absolute w-64 h-64 bg-emerald-500/20 dark:bg-emerald-500/10 rounded-full blur-3xl -z-10"></div>
          <div className="relative w-64 h-64">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle 
                className="text-gray-200 dark:text-gray-700 stroke-current" 
                cx="50" cy="50" fill="transparent" r={radius} strokeWidth="6"
              ></circle>
              <motion.circle 
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset: circumference - (progress / 100) * circumference }}
                transition={{ duration: 0.5, ease: "linear" }}
                className="text-emerald-500 stroke-current" 
                cx="50" cy="50" fill="transparent" r={radius} 
                strokeDasharray={circumference} 
                strokeLinecap="round" 
                strokeWidth="6"
              />
            </svg>
            <div className="absolute top-0 left-0 w-full h-full flex flex-col items-center justify-center text-center">
              <span className="text-sm uppercase tracking-widest text-gray-500 dark:text-gray-400 mb-1">Şu an</span>
              <h2 className="text-3xl font-display font-bold text-gray-900 dark:text-white mb-1">
                {prayerNames[activePrayerKey] || 'Vakit'}
              </h2>
              <div className="h-px w-12 bg-gray-300 dark:bg-gray-700 my-2"></div>
              <span className="text-xs text-gray-500 dark:text-gray-400">
                {prayerNames[nextPrayerName]}'a Kalan
              </span>
              <span className="text-4xl font-mono font-medium text-emerald-600 dark:text-emerald-500 mt-1 tabular-nums tracking-tight">
                {timeLeft}
              </span>
            </div>
          </div>
          <div className="mt-4 flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 px-3 py-1.5 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
            <Watch className="w-4 h-4" />
            <span>Saatinizle senkronize</span>
          </div>
        </div>

        {/* Prayer Times List */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
          <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
            <h3 className="font-semibold text-gray-900 dark:text-white">Vakitler</h3>
            <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded text-[10px] uppercase">Vasatî</span>
          </div>
          <div className="divide-y divide-gray-100 dark:divide-gray-700">
            {prayers.map((prayer) => {
              const isActive = prayer.key === activePrayerKey;
              return (
                <div 
                  key={prayer.key}
                  className={`flex items-center justify-between p-4 transition-colors ${
                    isActive 
                      ? 'bg-emerald-50 dark:bg-emerald-900/20 relative overflow-hidden' 
                      : 'hover:bg-gray-50 dark:hover:bg-gray-700/50'
                  }`}
                >
                  {isActive && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500"></div>
                  )}
                  <div className="flex items-center space-x-3 pl-1">
                    <prayer.icon className={`w-5 h-5 ${isActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-400 dark:text-gray-500'}`} />
                    <span className={`font-medium ${isActive ? 'text-emerald-700 dark:text-emerald-300' : 'text-gray-700 dark:text-gray-300'}`}>
                      {prayer.name}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {isActive && (
                      <span className="text-[10px] uppercase font-bold text-white bg-emerald-500 px-1.5 py-0.5 rounded">Şimdi</span>
                    )}
                    <span className={`font-mono font-semibold ${isActive ? 'text-emerald-700 dark:text-emerald-300' : 'text-gray-900 dark:text-white'}`}>
                      {prayer.time}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quote Card */}
        <div className="bg-gradient-to-br from-indigo-50 to-blue-50 dark:from-gray-800 dark:to-slate-800 rounded-2xl p-5 border border-indigo-100 dark:border-gray-700 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Quote className="w-16 h-16 text-indigo-900 dark:text-white" />
          </div>
          <div className="relative z-10">
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-2">Günün Sözü</h4>
            <p className="text-gray-700 dark:text-gray-300 italic text-sm leading-relaxed mb-3">
              "{quote?.quote || 'Yükleniyor...'}"
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">— {quote?.author || '...'}</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <button className="flex flex-col items-center justify-center p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm hover:shadow-md transition-all group">
            <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <Compass className="text-emerald-600 dark:text-emerald-400 w-6 h-6" />
            </div>
            <span className="text-sm font-medium text-gray-800 dark:text-gray-200">Kıble Yönü</span>
            <span className="text-xs text-gray-400 mt-1">11:44 Vakti</span>
          </button>
          <button className="flex flex-col items-center justify-center p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm hover:shadow-md transition-all group">
            <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <Calendar className="text-blue-600 dark:text-blue-400 w-6 h-6" />
            </div>
            <span className="text-sm font-medium text-gray-800 dark:text-gray-200">Hicri Takvim</span>
            <span className="text-xs text-gray-400 mt-1">{getHijriDate(new Date()).split(' ').slice(1).join(' ')}</span>
          </button>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 pb-safe z-40">
        <div className="max-w-md mx-auto px-6 h-16 flex items-center justify-between text-xs font-medium">
          <button className="flex flex-col items-center space-y-1 text-emerald-600 dark:text-emerald-400">
            <Home className="w-6 h-6" />
            <span>Ana Sayfa</span>
          </button>
          <button className="flex flex-col items-center space-y-1 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
            <Compass className="w-6 h-6" />
            <span>Kıble</span>
          </button>
          <button onClick={onOpenSettings} className="flex flex-col items-center space-y-1 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
            <Settings className="w-6 h-6" />
            <span>Ayarlar</span>
          </button>
          <button className="flex flex-col items-center space-y-1 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
            <BookOpen className="w-6 h-6" />
            <span>Kuran</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
