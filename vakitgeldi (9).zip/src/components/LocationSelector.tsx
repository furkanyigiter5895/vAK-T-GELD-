import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { MapPin, Globe, Building2, Map, ArrowRight, Watch, ShieldCheck } from 'lucide-react';
import { City, District } from '../services/turktakvim';
import { cities as staticCities } from '../data/cities';
import { districts as staticDistricts } from '../data/districts';

interface LocationSelectorProps {
  onLocationSelect: (location: { name: string; cityID: string }) => void;
}

export default function LocationSelector({ onLocationSelect }: LocationSelectorProps) {
  const [cities, setCities] = useState<City[]>(staticCities);
  const [districts, setDistricts] = useState<District[]>([]);
  
  const [selectedCity, setSelectedCity] = useState<string>("");
  const [selectedDistrict, setSelectedDistrict] = useState<string>("");
  
  // Sort cities alphabetically on mount
  useEffect(() => {
    const sorted = [...staticCities].sort((a, b) => a.name.localeCompare(b.name, 'tr'));
    setCities(sorted);
  }, []);

  useEffect(() => {
    if (selectedCity) {
      const cityDistricts = staticDistricts[selectedCity] || [];
      // Sort alphabetically
      const sorted = [...cityDistricts].sort((a, b) => a.name.localeCompare(b.name, 'tr'));
      setDistricts(sorted);
      setSelectedDistrict("");
    } else {
      setDistricts([]);
    }
  }, [selectedCity]);

  const handleManualSelect = () => {
    if (selectedDistrict) {
      const district = districts.find(d => d.id === selectedDistrict);
      if (district) {
        // We use the district name as the display name, but maybe combine with city
        const city = cities.find(c => c.value === selectedCity);
        const displayName = city ? `${city.name} / ${district.name}` : district.name;
        onLocationSelect({
          name: displayName,
          cityID: district.id
        });
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-gray-50 to-emerald-50 dark:from-gray-900 dark:to-emerald-900 transition-colors duration-300 font-sans text-gray-900 dark:text-gray-100">
      <div className="h-12 w-full shrink-0"></div>
      <main className="flex-1 flex flex-col px-6 pb-8 max-w-md mx-auto w-full justify-between">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 text-center space-y-2"
        >
          <div className="mx-auto w-16 h-16 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/30 mb-6">
            <Building2 className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
            Hoş Geldiniz
          </h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            Namaz vakitlerini doğru hesaplamak için lütfen konumunuzu belirleyin.
          </p>
        </motion.div>

        <div className="flex-1 flex flex-col justify-center space-y-6 py-8">
          
          <div className="space-y-4">
            <div className="relative group">
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1 ml-1">Ülke</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Globe className="text-gray-400 group-focus-within:text-emerald-600 w-5 h-5" />
                </span>
                <select disabled className="block w-full pl-10 pr-10 py-3.5 text-base border-gray-200 dark:border-gray-700 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 shadow-sm appearance-none cursor-not-allowed">
                  <option>Türkiye</option>
                </select>
                <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </span>
              </div>
            </div>

            <div className="relative group">
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1 ml-1">Şehir (İl)</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Building2 className="text-gray-400 group-focus-within:text-emerald-600 w-5 h-5" />
                </span>
                <select 
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="block w-full pl-10 pr-10 py-3.5 text-base border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm transition-shadow appearance-none cursor-pointer"
                >
                  <option value="" disabled>Şehir Seçiniz</option>
                  {cities.map(city => (
                    <option key={city.value} value={city.value}>{city.name}</option>
                  ))}
                </select>
                <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </span>
              </div>
            </div>

            <div className="relative group">
              <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1 ml-1">İlçe</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Map className="text-gray-400 group-focus-within:text-emerald-600 w-5 h-5" />
                </span>
                <select 
                  value={selectedDistrict}
                  onChange={(e) => setSelectedDistrict(e.target.value)}
                  disabled={!selectedCity}
                  className="block w-full pl-10 pr-10 py-3.5 text-base border-gray-200 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm transition-shadow appearance-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <option value="" disabled>İlçe Seçiniz</option>
                  {districts.map(district => (
                    <option key={district.id} value={district.id}>{district.name}</option>
                  ))}
                </select>
                <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <button 
            onClick={handleManualSelect}
            disabled={!selectedDistrict}
            className="w-full bg-gray-900 dark:bg-white text-white dark:text-gray-900 font-semibold py-4 rounded-xl shadow-lg hover:shadow-xl transition-all active:scale-95 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span>Devam Et</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          
          <div className="flex justify-center items-center space-x-4 pt-2">
            <span className="text-xs text-gray-400 dark:text-gray-500 flex items-center">
              <Watch className="w-4 h-4 mr-1" />
              Apple Watch Uyumlu
            </span>
            <span className="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-600"></span>
            <span className="text-xs text-gray-400 dark:text-gray-500 flex items-center">
              <ShieldCheck className="w-4 h-4 mr-1" />
              Gizlilik Odaklı
            </span>
          </div>
        </div>
      </main>
    </div>
  );
}
