export const cities = [
  {
    "name": "Adana",
    "value": "ADANA"
  },
  {
    "name": "Adıyaman",
    "value": "ADIYAMAN"
  },
  {
    "name": "Afyonkarahisar",
    "value": "AFYON"
  },
  {
    "name": "Ağrı",
    "value": "AGRI"
  },
  {
    "name": "Aksaray",
    "value": "AKSARAY"
  },
  {
    "name": "Aladağ",
    "value": "ALADAG"
  },
  {
    "name": "Alanya",
    "value": "ALANYA"
  },
  {
    "name": "Alaşehir",
    "value": "ALASEHIR"
  },
  {
    "name": "Aliağa",
    "value": "ALIAGA"
  },
  {
    "name": "Alpu",
    "value": "ALBU"
  },
  {
    "name": "Altındağ",
    "value": "ALDINDAG"
  },
  {
    "name": "Altınekin",
    "value": "ALDINEKIN"
  },
  {
    "name": "Altıntaş",
    "value": "ALDINDAS"
  },
  {
    "name": "Altınyayla",
    "value": "ALDINYAYLA"
  },
  {
    "name": "Alucra",
    "value": "ALUCRA"
  },
  {
    "name": "Amasya",
    "value": "AMASYA"
  },
  {
    "name": "Ankara",
    "value": "ANKARA"
  },
  {
    "name": "Antalya",
    "value": "ANDALYA"
  },
  {
    "name": "Araban",
    "value": "ARABAN"
  },
  {
    "name": "Araç",
    "value": "ARAC"
  },
  {
    "name": "Araklı",
    "value": "ARAKLI"
  },
  {
    "name": "Ardahan",
    "value": "ARDAHAN"
  },
  {
    "name": "Ardanuç",
    "value": "ARDANUC"
  },
  {
    "name": "Arpaçay",
    "value": "ARBACAY"
  },
  {
    "name": "Artvin",
    "value": "ARDVIN"
  },
  {
    "name": "Aslanapa",
    "value": "ASLANABA"
  },
  {
    "name": "Aşkale",
    "value": "ASKALE"
  },
  {
    "name": "Ayaş",
    "value": "AYAS"
  },
  {
    "name": "Aydın",
    "value": "AYDIN"
  },
  {
    "name": "Ayvacık",
    "value": "AYVACIK"
  },
  {
    "name": "Ayvalık",
    "value": "AYVALIK"
  },
  {
    "name": "Azdavay",
    "value": "AZDAVAY"
  },
  {
    "name": "Bafra",
    "value": "BAFRA"
  },
  {
    "name": "Baklan",
    "value": "BAKLAN"
  },
  {
    "name": "Bala",
    "value": "BALA"
  },
  {
    "name": "Balıkesir",
    "value": "BALIKESIR"
  },
  {
    "name": "Balya",
    "value": "BALYA"
  },
  {
    "name": "Banaz",
    "value": "BANAZ"
  },
  {
    "name": "Bartın",
    "value": "BARDIN"
  },
  {
    "name": "Batman",
    "value": "BADMAN"
  },
  {
    "name": "Bayat",
    "value": "BAYAD"
  },
  {
    "name": "Bayburt",
    "value": "BAYBURD"
  },
  {
    "name": "Bayramiç",
    "value": "BAYRAMIC"
  },
  {
    "name": "Besni",
    "value": "BESNI"
  },
  {
    "name": "Beşikdüzü",
    "value": "BESIKDUZU"
  },
  {
    "name": "Beydağ",
    "value": "BEYDAG"
  },
  {
    "name": "Beyşehir",
    "value": "BEYSEHIR"
  },
  {
    "name": "Beytüşşebap",
    "value": "BEYDUSEBAB"
  },
  {
    "name": "Biga",
    "value": "BIGA"
  },
  {
    "name": "Bigadiç",
    "value": "BIGADIC"
  },
  {
    "name": "Bilecik",
    "value": "BILECIK"
  },
  {
    "name": "Bingöl",
    "value": "BINGOL"
  },
  {
    "name": "Bismil",
    "value": "BISMIL"
  },
  {
    "name": "Bitlis",
    "value": "BIDLIS"
  },
  {
    "name": "Bodrum",
    "value": "BODRUM"
  },
  {
    "name": "Boğazkale",
    "value": "BOGAZKALE"
  },
  {
    "name": "Bolu",
    "value": "BOLU"
  },
  {
    "name": "Borçka",
    "value": "BORCKA"
  },
  {
    "name": "Bozkır",
    "value": "BOZKIR"
  },
  {
    "name": "Bozkurt",
    "value": "BOZKURD"
  },
  {
    "name": "Bozova",
    "value": "BOZOVA"
  },
  {
    "name": "Bozyazı",
    "value": "BOZYAZI"
  },
  {
    "name": "Bucak",
    "value": "BUCAK"
  },
  {
    "name": "Burdur",
    "value": "BURDUR"
  },
  {
    "name": "Burhaniye",
    "value": "BURHANIYE"
  },
  {
    "name": "Bursa",
    "value": "BURSA"
  },
  {
    "name": "Bünyan",
    "value": "BUNYAN"
  },
  {
    "name": "Canakkale",
    "value": "CANAKALE"
  },
  {
    "name": "Cihanbeyli",
    "value": "CIHANBEYLI"
  },
  {
    "name": "Cizre",
    "value": "CIZRE"
  },
  {
    "name": "Çamlıdere",
    "value": "CAMLIDERE"
  },
  {
    "name": "Çan",
    "value": "CAN"
  },
  {
    "name": "Çanakkale",
    "value": ";CANAKALE"
  },
  {
    "name": "Çandır",
    "value": "CANDIR"
  },
  {
    "name": "Çankaya",
    "value": "CANKAYA"
  },
  {
    "name": "Çankırı",
    "value": "CANKIRI"
  },
  {
    "name": "Çarşamba",
    "value": "CARSAMBA"
  },
  {
    "name": "Çat",
    "value": "CAD"
  },
  {
    "name": "Çavdarhisar",
    "value": "CAVDARHISAR"
  },
  {
    "name": "Çavdır",
    "value": "CAVDIR"
  },
  {
    "name": "Çaycuma",
    "value": "CAYCUMA"
  },
  {
    "name": "Çayırlı",
    "value": "CAYIRLI"
  },
  {
    "name": "Çelikhan",
    "value": "CELIKHAN"
  },
  {
    "name": "Çermik",
    "value": "CERMIK"
  },
  {
    "name": "Çeşme",
    "value": "CESME"
  },
  {
    "name": "Çınar",
    "value": "CINAR"
  },
  {
    "name": "Çiçekdağı",
    "value": "CICEKDAGI"
  },
  {
    "name": "Çifteler",
    "value": "CIFDELER"
  },
  {
    "name": "Çine",
    "value": "CINE"
  },
  {
    "name": "Çorum",
    "value": "CORUM"
  },
  {
    "name": "Çubuk",
    "value": "CUBUK"
  },
  {
    "name": "Çukurca",
    "value": "CUKURCA"
  },
  {
    "name": "Çumra",
    "value": "CUMRA"
  },
  {
    "name": "Çüngüş",
    "value": "CUNGUS"
  },
  {
    "name": "Daday",
    "value": "DADAY"
  },
  {
    "name": "Demirci",
    "value": "DEMIRCI"
  },
  {
    "name": "Denizli",
    "value": "DENIZLI"
  },
  {
    "name": "Derebucak",
    "value": "DEREBUCAK"
  },
  {
    "name": "Derik",
    "value": "DERIK"
  },
  {
    "name": "Develi",
    "value": "DEVELI"
  },
  {
    "name": "Devrekani",
    "value": "DEVREKANI"
  },
  {
    "name": "Digor",
    "value": "DIGOR"
  },
  {
    "name": "Dikili",
    "value": "DIKILI"
  },
  {
    "name": "Dinar",
    "value": "DINAR"
  },
  {
    "name": "Divriği",
    "value": "DIVRIGI"
  },
  {
    "name": "Diyarbakır",
    "value": "DIYARBAKI"
  },
  {
    "name": "Diyarbakır",
    "value": "DIYARBAKIR"
  },
  {
    "name": "Doğanyurt",
    "value": "DOGANYURD"
  },
  {
    "name": "Doğubayazıt",
    "value": "DOGUBAYAZID"
  },
  {
    "name": "Domaniç",
    "value": "DOMANIC"
  },
  {
    "name": "Dursunbey",
    "value": "DURSUNBEY"
  },
  {
    "name": "Düzce",
    "value": "DUZCE"
  },
  {
    "name": "Düziçi",
    "value": "DUZICI"
  },
  {
    "name": "Edirne",
    "value": "EDIRNE"
  },
  {
    "name": "Eğil",
    "value": "EGIL"
  },
  {
    "name": "Elazığ",
    "value": "ELAZIG"
  },
  {
    "name": "Eleşkirt",
    "value": "ELESKIRD"
  },
  {
    "name": "Elmadağ",
    "value": "ELMADAG"
  },
  {
    "name": "Elmalı",
    "value": "ELMALI"
  },
  {
    "name": "Emet",
    "value": "EMED"
  },
  {
    "name": "Emirdağ",
    "value": "EMIRDAG"
  },
  {
    "name": "Erbaa",
    "value": "ERBA"
  },
  {
    "name": "Erciş",
    "value": "ERCIS"
  },
  {
    "name": "Erdemli",
    "value": "ERDEMLI"
  },
  {
    "name": "Ereğli",
    "value": "EREGLI"
  },
  {
    "name": "Ergani",
    "value": "ERGANI"
  },
  {
    "name": "Erzincan",
    "value": "ERZINCAN"
  },
  {
    "name": "Erzurum",
    "value": "ERZURUM"
  },
  {
    "name": "Eskişehir",
    "value": "ESKISEHIR"
  },
  {
    "name": "Eskişehir / Alpu",
    "value": "ESKISEHIRALBU"
  },
  {
    "name": "Ezine",
    "value": "EZINE"
  },
  {
    "name": "Feke",
    "value": "FEKE"
  },
  {
    "name": "Finike",
    "value": "FINIKE"
  },
  {
    "name": "Gaziantep",
    "value": "GAZIANDEB"
  },
  {
    "name": "Gebze",
    "value": "GEBZE"
  },
  {
    "name": "Gediz",
    "value": "GEDIZ"
  },
  {
    "name": "Gercüş",
    "value": "GERCUS"
  },
  {
    "name": "Giresun",
    "value": "GIRESUN"
  },
  {
    "name": "Göksun",
    "value": "GOKSUN"
  },
  {
    "name": "Gölbaşı",
    "value": "GOLBASI"
  },
  {
    "name": "Göle",
    "value": "GOLE"
  },
  {
    "name": "Gölmarmara",
    "value": "GOLMARMARA"
  },
  {
    "name": "Gölova",
    "value": "GOLOVA"
  },
  {
    "name": "Gönen",
    "value": "GONEN"
  },
  {
    "name": "Görele",
    "value": "GORELE"
  },
  {
    "name": "Göynük",
    "value": "GOYNUK"
  },
  {
    "name": "Güdül",
    "value": "GUDUL"
  },
  {
    "name": "Gülnar",
    "value": "GULNAR"
  },
  {
    "name": "Gümüşhane",
    "value": "GUMUSHANE"
  },
  {
    "name": "Gürpınar",
    "value": "GURBINAR"
  },
  {
    "name": "Gürün",
    "value": "GURUN"
  },
  {
    "name": "Hafik",
    "value": "HAFIK"
  },
  {
    "name": "Hakkâri",
    "value": "HAKARI"
  },
  {
    "name": "Hakkâri",
    "value": "HAKRI"
  },
  {
    "name": "Halab",
    "value": "GAZIANDEB;HALAB"
  },
  {
    "name": "Hatay",
    "value": "HADAY"
  },
  {
    "name": "Havza",
    "value": "HAVZA"
  },
  {
    "name": "Haymana",
    "value": "HAYMANA"
  },
  {
    "name": "Hekimhan",
    "value": "HEKIMHAN"
  },
  {
    "name": "Hınıs",
    "value": "HINIS"
  },
  {
    "name": "Hilvan",
    "value": "HILVAN"
  },
  {
    "name": "Hisarcık",
    "value": "HISARCIK"
  },
  {
    "name": "Hocalar",
    "value": "HOCALAR"
  },
  {
    "name": "Hopa",
    "value": "HOBA"
  },
  {
    "name": "Horasan",
    "value": "HORASAN"
  },
  {
    "name": "Hozat",
    "value": "HOZAD"
  },
  {
    "name": "Iğdır",
    "value": "IGDIR"
  },
  {
    "name": "Ilgın",
    "value": "ILGIN"
  },
  {
    "name": "Ilıca",
    "value": "ILICA"
  },
  {
    "name": "Isparta",
    "value": "ISBARDA"
  },
  {
    "name": "İliç",
    "value": "ILIC"
  },
  {
    "name": "İmranlı",
    "value": "IMRANLI"
  },
  {
    "name": "İmroz",
    "value": "IMROZ"
  },
  {
    "name": "İncesu",
    "value": "INCESU"
  },
  {
    "name": "İnegöl",
    "value": "INEGOL"
  },
  {
    "name": "İskilip",
    "value": "ISKILIB"
  },
  {
    "name": "İspir",
    "value": "ISBIR"
  },
  {
    "name": "İstanbul",
    "value": "ISDANBUL"
  },
  {
    "name": "İzmir",
    "value": "IZMIR"
  },
  {
    "name": "İznik",
    "value": "IZNIK"
  },
  {
    "name": "Kağızman",
    "value": "KAGIZMAN"
  },
  {
    "name": "Kahramanmaraş",
    "value": "KAHRAMANMARAS"
  },
  {
    "name": "Kahta",
    "value": "KAHDA"
  },
  {
    "name": "Kale",
    "value": "KALE"
  },
  {
    "name": "Kalecik",
    "value": "KALECIK"
  },
  {
    "name": "Kaman",
    "value": "KAMAN"
  },
  {
    "name": "Kangal",
    "value": "KANGAL"
  },
  {
    "name": "Karaburun",
    "value": "KARABURUN"
  },
  {
    "name": "Karabük",
    "value": "KARABUK"
  },
  {
    "name": "Karacabey",
    "value": "KARACABEY"
  },
  {
    "name": "Karaisalı",
    "value": "KARAISALI"
  },
  {
    "name": "Karakoçan",
    "value": "KARAKOCAN"
  },
  {
    "name": "Karaman",
    "value": "KARAMAN"
  },
  {
    "name": "Karapınar",
    "value": "KARABINAR"
  },
  {
    "name": "Karasu",
    "value": "KARASU"
  },
  {
    "name": "Karatay",
    "value": "KARADAY"
  },
  {
    "name": "Kars",
    "value": "KARS"
  },
  {
    "name": "Kastamonu",
    "value": "KASDAMONU"
  },
  {
    "name": "Kavak",
    "value": "KAVAK"
  },
  {
    "name": "Kayseri",
    "value": "KAYSERI"
  },
  {
    "name": "Keçiborlu",
    "value": "KECIBORLU"
  },
  {
    "name": "Keles",
    "value": "KELES"
  },
  {
    "name": "Kemah",
    "value": "KEMAH"
  },
  {
    "name": "Kemer",
    "value": "KEMER"
  },
  {
    "name": "Kepsut",
    "value": "KEBSUD"
  },
  {
    "name": "Kestel",
    "value": "KESDEL"
  },
  {
    "name": "Kınık",
    "value": "KINIK"
  },
  {
    "name": "Kırıkhan",
    "value": "KIRIKHAN"
  },
  {
    "name": "Kırıkkale",
    "value": "KIRIKALE"
  },
  {
    "name": "Kırklareli",
    "value": "KIRKLARELI"
  },
  {
    "name": "Kırşehir",
    "value": "KIRSEHIR"
  },
  {
    "name": "Kızılcahamam",
    "value": "KIZILCAHAMAM"
  },
  {
    "name": "Kızıltepe",
    "value": "KIZILDEBE"
  },
  {
    "name": "Kilis",
    "value": "KILIS"
  },
  {
    "name": "Kiraz",
    "value": "KIRAZ"
  },
  {
    "name": "Kocaeli",
    "value": "KOCAELI"
  },
  {
    "name": "Kocasinan",
    "value": "KOCASINAN"
  },
  {
    "name": "Koçarlı",
    "value": "KOCARLI"
  },
  {
    "name": "Konya",
    "value": "KONYA"
  },
  {
    "name": "Korkuteli",
    "value": "KORKUDELI"
  },
  {
    "name": "Kovancılar",
    "value": "KOVANCILAR"
  },
  {
    "name": "Koyulhisar",
    "value": "KOYULHISAR"
  },
  {
    "name": "Kozan",
    "value": "KOZAN"
  },
  {
    "name": "Köprübaşı",
    "value": "KOBRUBASI"
  },
  {
    "name": "Köprüköy",
    "value": "KOBRUKOY"
  },
  {
    "name": "Kula",
    "value": "KULA"
  },
  {
    "name": "Kumluca",
    "value": "KUMLUCA"
  },
  {
    "name": "Kuyucak",
    "value": "KUYUCAK"
  },
  {
    "name": "Küre",
    "value": "KURE"
  },
  {
    "name": "Kütahya",
    "value": "KUDAHYA"
  },
  {
    "name": "Lüleburgaz",
    "value": "LULEBURGAZ"
  },
  {
    "name": "M. Kemalpaşa",
    "value": "MKEMALBASA"
  },
  {
    "name": "Mahmudiye",
    "value": "MAHMUDIYE"
  },
  {
    "name": "Malatya",
    "value": "MALADYA"
  },
  {
    "name": "Manavgat",
    "value": "MANAVGAD"
  },
  {
    "name": "Manisa",
    "value": "MANISA"
  },
  {
    "name": "Mardin",
    "value": "MARDIN"
  },
  {
    "name": "Marmaris",
    "value": "MARMARIS"
  },
  {
    "name": "Marmaris / Muğla",
    "value": "MARMARISMUGLA"
  },
  {
    "name": "Mecitözü",
    "value": "MECIDOZU"
  },
  {
    "name": "Menderes",
    "value": "MENDERES"
  },
  {
    "name": "Menemen",
    "value": "MENEMEN"
  },
  {
    "name": "Mengen",
    "value": "MENGEN"
  },
  {
    "name": "Meram",
    "value": "MERAM"
  },
  {
    "name": "Mersin",
    "value": "MERSIN"
  },
  {
    "name": "Mihalıçcık",
    "value": "MIHALICIK"
  },
  {
    "name": "Milas",
    "value": "MILAS"
  },
  {
    "name": "Muğla",
    "value": "MUGLA"
  },
  {
    "name": "Muş",
    "value": "MUS"
  },
  {
    "name": "Mut",
    "value": "MUD"
  },
  {
    "name": "Nallıhan",
    "value": "NALIHAN"
  },
  {
    "name": "Nazilli",
    "value": "NAZILI"
  },
  {
    "name": "Nevşehir",
    "value": "NEVSEHIR"
  },
  {
    "name": "Niğde",
    "value": "NIGDE"
  },
  {
    "name": "Niksar",
    "value": "NIKSAR"
  },
  {
    "name": "Nurhak",
    "value": "NURHAK"
  },
  {
    "name": "Oltu",
    "value": "OLDU"
  },
  {
    "name": "Ordu",
    "value": "ORDU"
  },
  {
    "name": "Orhaneli",
    "value": "ORHANELI"
  },
  {
    "name": "Orhangazi",
    "value": "ORHANGAZI"
  },
  {
    "name": "Ortaca",
    "value": "ORDACA"
  },
  {
    "name": "Osmancık",
    "value": "OSMANCIK"
  },
  {
    "name": "Osmaniye",
    "value": "OSMANIYE"
  },
  {
    "name": "Ödemiş",
    "value": "ODEMIS"
  },
  {
    "name": "Pamukova",
    "value": "BAMUKOVA"
  },
  {
    "name": "Pasinler",
    "value": "BASINLER"
  },
  {
    "name": "Pazar",
    "value": "BAZAR"
  },
  {
    "name": "Pazarcık",
    "value": "BAZARCIK"
  },
  {
    "name": "Pazaryolu",
    "value": "BAZARYOLU"
  },
  {
    "name": "Pertek",
    "value": "BERDEK"
  },
  {
    "name": "Pınarbaşı",
    "value": "BINARBASI"
  },
  {
    "name": "Polatlı",
    "value": "BOLADLI"
  },
  {
    "name": "Posof",
    "value": "BOSOF"
  },
  {
    "name": "Pülümür",
    "value": "BULUMUR"
  },
  {
    "name": "Rize",
    "value": "RIZE"
  },
  {
    "name": "Safranbolu",
    "value": "SAFRANBOLU"
  },
  {
    "name": "Sakarya",
    "value": "SAKARYA"
  },
  {
    "name": "Samsun",
    "value": "SAMSUN"
  },
  {
    "name": "Sandıklı",
    "value": "SANDIKLI"
  },
  {
    "name": "Sapanca",
    "value": "SABANCA"
  },
  {
    "name": "Saray",
    "value": "SARAY"
  },
  {
    "name": "Saraykent",
    "value": "SARAYKEND"
  },
  {
    "name": "Sarayköy",
    "value": "SARAYKOY"
  },
  {
    "name": "Sarayönü",
    "value": "SARAYONU"
  },
  {
    "name": "Sarıkamış",
    "value": "SARIKAMIS"
  },
  {
    "name": "Sarıkaya",
    "value": "SARIKAYA"
  },
  {
    "name": "Sarıoğlan",
    "value": "SARIOGLAN"
  },
  {
    "name": "Sarız",
    "value": "SARIZ"
  },
  {
    "name": "Savaştepe",
    "value": "SAVASDEBE"
  },
  {
    "name": "Savur",
    "value": "SAVUR"
  },
  {
    "name": "Seben",
    "value": "SEBEN"
  },
  {
    "name": "Seferihisar / İzmir",
    "value": "SEFERIHISARIZMIR"
  },
  {
    "name": "Selendi",
    "value": "SELENDI"
  },
  {
    "name": "Selim",
    "value": "SELIM"
  },
  {
    "name": "Serik",
    "value": "SERIK"
  },
  {
    "name": "Seydişehir",
    "value": "SEYDISEHIR"
  },
  {
    "name": "Sındırgı",
    "value": "SINDIRGI"
  },
  {
    "name": "Siirt",
    "value": "SIRD"
  },
  {
    "name": "Silifke",
    "value": "SILIFKE"
  },
  {
    "name": "Silopi",
    "value": "SILOBI"
  },
  {
    "name": "Silvan",
    "value": "SILVAN"
  },
  {
    "name": "Simav",
    "value": "SIMAV"
  },
  {
    "name": "Sincik",
    "value": "SINCIK"
  },
  {
    "name": "Sinop",
    "value": "SINOB"
  },
  {
    "name": "Sivas",
    "value": "SIVAS"
  },
  {
    "name": "Siverek",
    "value": "SIVEREK"
  },
  {
    "name": "Sivrice",
    "value": "SIVRICE"
  },
  {
    "name": "Sivrihisar",
    "value": "SIVRIHISAR"
  },
  {
    "name": "Soma",
    "value": "SOMA"
  },
  {
    "name": "Sorgun",
    "value": "SORGUN"
  },
  {
    "name": "Söğütlü",
    "value": "SOGUDLU"
  },
  {
    "name": "Susurluk",
    "value": "SUSURLUK"
  },
  {
    "name": "Susuz",
    "value": "SUSUZ"
  },
  {
    "name": "Şahinbey",
    "value": "SAHINBEY"
  },
  {
    "name": "Şanlıurfa",
    "value": "SANLIURFA"
  },
  {
    "name": "Şarkışla",
    "value": "SARKISLA"
  },
  {
    "name": "Şavşat",
    "value": "SAVSAD"
  },
  {
    "name": "Şehitkamil",
    "value": "SEHIDKAMIL"
  },
  {
    "name": "Şemdinli",
    "value": "SEMDINLI"
  },
  {
    "name": "Şenkaya",
    "value": "SENKAYA"
  },
  {
    "name": "Şenpazar",
    "value": "SENBAZAR"
  },
  {
    "name": "Şereflikoçhisar",
    "value": "SEREFLIKOCHISAR"
  },
  {
    "name": "Şırnak",
    "value": "SIRNAK"
  },
  {
    "name": "Şile",
    "value": "SILE"
  },
  {
    "name": "Şuhut",
    "value": "SUHUD"
  },
  {
    "name": "Taşköprü",
    "value": "DASKOBRU"
  },
  {
    "name": "Tatvan",
    "value": "DADVAN"
  },
  {
    "name": "Tavas",
    "value": "DAVAS"
  },
  {
    "name": "Tavşanlı",
    "value": "DAVSANLI"
  },
  {
    "name": "Tekirdağ",
    "value": "DEKIRDAG"
  },
  {
    "name": "Tekkeköy",
    "value": "DEKEKOY"
  },
  {
    "name": "Tekman",
    "value": "DEKMAN"
  },
  {
    "name": "Tercan",
    "value": "DERCAN"
  },
  {
    "name": "Terme",
    "value": "DERME"
  },
  {
    "name": "Tire",
    "value": "DIRE"
  },
  {
    "name": "Tokat",
    "value": "DOKAD"
  },
  {
    "name": "Tomarza",
    "value": "DOMARZA"
  },
  {
    "name": "Toprakkale",
    "value": "DOBRAKALE"
  },
  {
    "name": "Torbalı",
    "value": "DORBALI"
  },
  {
    "name": "Tortum",
    "value": "DORDUM"
  },
  {
    "name": "Tosya",
    "value": "DOSYA"
  },
  {
    "name": "Trabzon",
    "value": "DRABZON"
  },
  {
    "name": "Tunceli",
    "value": "DUNCELI"
  },
  {
    "name": "Turgutlu",
    "value": "DURGUDLU"
  },
  {
    "name": "Ula",
    "value": "ULA"
  },
  {
    "name": "Ulaş",
    "value": "ULAS"
  },
  {
    "name": "Ulukışla",
    "value": "ULUKISLA"
  },
  {
    "name": "Urla",
    "value": "URLA"
  },
  {
    "name": "Uşak",
    "value": "USAK"
  },
  {
    "name": "Ünye",
    "value": "UNYE"
  },
  {
    "name": "Ürgüp",
    "value": "URGUB"
  },
  {
    "name": "Üzümlü",
    "value": "UZUMLU"
  },
  {
    "name": "Van",
    "value": "VAN"
  },
  {
    "name": "Varto",
    "value": "VARDO"
  },
  {
    "name": "Vezirköprü",
    "value": "VEZIRKOBRU"
  },
  {
    "name": "Viranşehir",
    "value": "VIRANSEHIR"
  },
  {
    "name": "Yahyalı",
    "value": "YAHYALI"
  },
  {
    "name": "Yalova",
    "value": "YALOVA"
  },
  {
    "name": "Yatağan",
    "value": "YADAGAN"
  },
  {
    "name": "Yazıhan",
    "value": "YAZIHAN"
  },
  {
    "name": "Yenice",
    "value": "YENICE"
  },
  {
    "name": "Yenieşme",
    "value": "YENIESME"
  },
  {
    "name": "Yenimahalle",
    "value": "YENIMAHALE"
  },
  {
    "name": "Yenipazar",
    "value": "YENIBAZAR"
  },
  {
    "name": "Yenişehir",
    "value": "YENISEHIR"
  },
  {
    "name": "Yıldızeli",
    "value": "YILDIZELI"
  },
  {
    "name": "Yozgat",
    "value": "YOZGAD"
  },
  {
    "name": "Yumurtalık",
    "value": "YUMURDALIK"
  },
  {
    "name": "Yunak",
    "value": "YUNAK"
  },
  {
    "name": "Yusufeli",
    "value": "YUSUFELI"
  },
  {
    "name": "Yüksekova",
    "value": "YUKSEKOVA"
  },
  {
    "name": "Zara",
    "value": "ZARA"
  },
  {
    "name": "Zonguldak",
    "value": "ZONGULDAK"
  }
];