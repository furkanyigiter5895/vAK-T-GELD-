import { Coordinates, CalculationMethod, PrayerTimes, Madhab } from 'adhan';

export interface PrayerTimeData {
  fajr: Date;
  sunrise: Date;
  dhuhr: Date;
  asr: Date;
  maghrib: Date;
  isha: Date;
  nextPrayer: string;
  nextPrayerTime: Date;
  timeLeft: string; // HH:MM:SS
}

export function getPrayerTimes(latitude: number, longitude: number, date: Date = new Date()): PrayerTimeData {
  const coordinates = new Coordinates(latitude, longitude);
  const params = CalculationMethod.Turkey();
  params.madhab = Madhab.Hanafi; // Common in Turkey
  
  const prayerTimes = new PrayerTimes(coordinates, date, params);
  
  // Calculate next prayer
  const now = new Date();
  let nextPrayerName = prayerTimes.nextPrayer();
  let nextPrayerTime = prayerTimes.timeForPrayer(nextPrayerName);

  // If next prayer is none (after Isha), it's Fajr tomorrow
  if (nextPrayerName === 'none') {
    const tomorrow = new Date(date);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowTimes = new PrayerTimes(coordinates, tomorrow, params);
    nextPrayerName = 'fajr';
    nextPrayerTime = tomorrowTimes.fajr;
  }

  // Calculate time left
  const diff = nextPrayerTime.getTime() - now.getTime();
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);
  
  const timeLeft = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  return {
    fajr: prayerTimes.fajr,
    sunrise: prayerTimes.sunrise,
    dhuhr: prayerTimes.dhuhr,
    asr: prayerTimes.asr,
    maghrib: prayerTimes.maghrib,
    isha: prayerTimes.isha,
    nextPrayer: nextPrayerName,
    nextPrayerTime: nextPrayerTime,
    timeLeft
  };
}

export function formatTime(date: Date): string {
  return date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
}

export function getHijriDate(date: Date): string {
  return new Intl.DateTimeFormat('tr-TR-u-ca-islamic', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(date).replace(' AH', '');
}

export function getGregorianDate(date: Date): string {
  return new Intl.DateTimeFormat('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    weekday: 'long'
  }).format(date);
}
