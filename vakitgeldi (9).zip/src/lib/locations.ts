export interface City {
  name: string;
  latitude: number;
  longitude: number;
}

export const CITIES: City[] = [
  { name: "İstanbul", latitude: 41.0082, longitude: 28.9784 },
  { name: "Ankara", latitude: 39.9334, longitude: 32.8597 },
  { name: "İzmir", latitude: 38.4192, longitude: 27.1287 },
  { name: "Bursa", latitude: 40.1885, longitude: 29.0610 },
  { name: "Antalya", latitude: 36.8969, longitude: 30.7133 },
  { name: "Adana", latitude: 37.0000, longitude: 35.3213 },
  { name: "Konya", latitude: 37.8667, longitude: 32.4833 },
  { name: "Gaziantep", latitude: 37.0662, longitude: 37.3833 },
  { name: "Şanlıurfa", latitude: 37.1591, longitude: 38.7969 },
  { name: "Kocaeli", latitude: 40.8533, longitude: 29.8815 },
  { name: "Mersin", latitude: 36.8000, longitude: 34.6333 },
  { name: "Diyarbakır", latitude: 37.9144, longitude: 40.2306 },
  { name: "Hatay", latitude: 36.4018, longitude: 36.3498 },
  { name: "Manisa", latitude: 38.6191, longitude: 27.4289 },
  { name: "Kayseri", latitude: 38.7312, longitude: 35.4787 },
  { name: "Samsun", latitude: 41.2867, longitude: 36.3300 },
  { name: "Balıkesir", latitude: 39.6484, longitude: 27.8826 },
  { name: "Kahramanmaraş", latitude: 37.5858, longitude: 36.9371 },
  { name: "Van", latitude: 38.4891, longitude: 43.4089 },
  { name: "Aydın", latitude: 37.8560, longitude: 27.8416 },
];
