import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { cities } from './src/data/cities';

async function fetchAndSaveDistricts() {
  const allDistricts: Record<string, any[]> = {};
  const failedCities: string[] = [];

  console.log(`Fetching districts for ${cities.length} cities...`);

  for (let i = 0; i < cities.length; i++) {
    const city = cities[i];
    const cityValue = city.value;
    
    try {
      // Add a small delay to be nice
      await new Promise(resolve => setTimeout(resolve, 50));
      
      console.log(`[${i+1}/${cities.length}] Fetching ${city.name} (${cityValue})...`);
      const response = await axios.get(`http://localhost:3000/api/locations/districts?city=${encodeURIComponent(cityValue)}`);
      
      if (response.data && Array.isArray(response.data)) {
        allDistricts[cityValue] = response.data;
        console.log(`  -> Found ${response.data.length} districts.`);
      } else {
        console.warn(`  -> Invalid response for ${city.name}`);
        failedCities.push(cityValue);
      }
    } catch (error) {
      console.error(`  -> Failed to fetch ${city.name}:`, error.message);
      failedCities.push(cityValue);
    }
  }

  console.log("Finished fetching.");
  if (failedCities.length > 0) {
    console.log(`Failed cities: ${failedCities.join(', ')}`);
  }

  const content = `export const districts: Record<string, {name: string, id: string}[]> = ${JSON.stringify(allDistricts, null, 2)};`;
  
  const dir = path.join(process.cwd(), 'src', 'data');
  if (!fs.existsSync(dir)){
      fs.mkdirSync(dir, { recursive: true });
  }
  
  fs.writeFileSync(path.join(dir, 'districts.ts'), content);
  console.log(`Saved districts to src/data/districts.ts`);
}

fetchAndSaveDistricts();
