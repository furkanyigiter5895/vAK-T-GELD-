import axios from 'axios';
import * as cheerio from 'cheerio';

async function inspect() {
  try {
    const url = 'https://www.namazvakti.com/';
    console.log(`Fetching ${url}...`);
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    const $ = cheerio.load(response.data);
    console.log("Title:", $('title').text());
    
    // Look for location selection elements (dropdowns, lists)
    console.log("Select elements:", $('select').length);
    $('select').each((i, el) => {
      console.log(`Select ${i} name:`, $(el).attr('name'), "id:", $(el).attr('id'));
      // console.log($(el).html().substring(0, 100));
    });

    // Try to find the city selection logic.
    // Often there's a link to "Change Location" or "Select City"
    // Let's look for links containing "Main.php" or similar.
    
    // Also check if there's a script tag with city data.
    $('script').each((i, el) => {
      const content = $(el).html();
      if (content && content.includes('cityID')) {
        console.log(`Script ${i} contains cityID logic (truncated):`, content.substring(0, 200));
      }
    });

    // Check for a form action
    $('form').each((i, el) => {
      console.log(`Form ${i} action:`, $(el).attr('action'));
    });

  } catch (error) {
    console.error(error);
  }
}

inspect();
