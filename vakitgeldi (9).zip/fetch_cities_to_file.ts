import axios from 'axios';
import fs from 'fs';
import path from 'path';

async function fetchAndSaveCities() {
  try {
    const response = await axios.get('http://localhost:3000/api/locations/cities');
    const cities = response.data;
    
    const content = `export const cities = ${JSON.stringify(cities, null, 2)};`;
    
    // Ensure directory exists
    const dir = path.join(process.cwd(), 'src', 'data');
    if (!fs.existsSync(dir)){
        fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(path.join(dir, 'cities.ts'), content);
    console.log(`Saved ${cities.length} cities to src/data/cities.ts`);
  } catch (error) {
    console.error("Failed to fetch cities:", error);
  }
}

fetchAndSaveCities();
