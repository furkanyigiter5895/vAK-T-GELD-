import axios from 'axios';

async function checkTimes() {
  try {
    const response = await axios.get('http://localhost:3000/api/times?cityID=16741');
    console.log("Times:", response.data);
  } catch (error) {
    console.error(error);
  }
}

checkTimes();
