import axios from 'axios';
import * as cheerio from 'cheerio';
import iconv from 'iconv-lite';

async function inspect() {
  try {
    const response = await axios.get('https://www.turktakvim.com/index.php?cityID=16702', {
      responseType: 'arraybuffer',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    // The site might be ISO-8859-9 (Turkish)
    const html = iconv.decode(response.data, 'iso-8859-9');
    const $ = cheerio.load(html);

    console.log("Title:", $('title').text());
    
    // Look for prayer times table
    const tables = $('table');
    console.log("Tables found:", tables.length);
    
    tables.each((i, table) => {
      console.log(`Table ${i}:`, $(table).text().substring(0, 200).replace(/\s+/g, ' '));
    });

    // Look for specific classes or ids
    console.log("Vakitler div:", $('.vakitler').length);
    console.log("Content:", $('body').text().substring(0, 500).replace(/\s+/g, ' '));

  } catch (error) {
    console.error(error);
  }
}

inspect();
